python testComputational.py -shortTerm
python testComputational.py -classifyFile
python testComputational.py -mtClassify
python testComputational.py -hmmSegmentation
python testComputational.py -silenceRemoval
python testComputational.py -thumbnailing
python testComputational.py -diarization-noLDA
python testComputational.py -diarization-LDA
